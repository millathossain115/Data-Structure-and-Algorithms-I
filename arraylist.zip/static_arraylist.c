#include <stdio.h>

int arr[100];
int size = 100;
int length;

void init() {
    length = 0;
}

void print() {
    for(int i=0; i<length; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int is_full() {
    // write your code here
}

int is_empty() {
    // write your code here
}

int insert_first(int item) {
    // write your code here
}

int insert_last(int item) {
    // write your code here
}

int insert_at(int item, int pos) {
    // write your code here
}

int search(int item) {
    // write your code here
}

int remove_first() {
    // write your code here
}

int remove_last() {
    // write your code here
}

int remove_at(int pos) {
    // write your code here
}

int remove_item_first(int item) {
    // write your code here
}

int remove_item_last(int item) {
    // write your code here
}

int remove_item_all(int item) {
    // write your code here
}

int replace(int old_item, int new_item) {
    // write your code here
}

void clear() {
    // write your code here
}

int main() {
    init(); // initializes the arraylist first
    // test your functions here


    return 0;
}
